package com.example.lbstest;

import java.util.ArrayList;
import com.baidu.mapapi.model.LatLng;
import com.baidu.mapapi.search.core.SearchResult;
import com.baidu.mapapi.search.route.BikingRoutePlanOption;
import com.baidu.mapapi.search.route.BikingRouteResult;
import com.baidu.mapapi.search.route.DrivingRoutePlanOption;
import com.baidu.mapapi.search.route.DrivingRouteResult;
import com.baidu.mapapi.search.route.IndoorRouteResult;
import com.baidu.mapapi.search.route.MassTransitRouteResult;
import com.baidu.mapapi.search.route.OnGetRoutePlanResultListener;
import com.baidu.mapapi.search.route.PlanNode;
import com.baidu.mapapi.search.route.RoutePlanSearch;
import com.baidu.mapapi.search.route.TransitRoutePlanOption;
import com.baidu.mapapi.search.route.TransitRouteResult;
import com.baidu.mapapi.search.route.WalkingRoutePlanOption;
import com.baidu.mapapi.search.route.WalkingRouteResult;
import android.content.Context;
import android.widget.Toast;

/**
 * @author 王家宇
 *
 */
public class BaiduSearch implements OnGetRoutePlanResultListener{
    private Context context;
    private RoutePlanSearch mSearch = null;    // 搜索模块，也可去掉地图模块独立使用

    /** 路径规划接口  */
    public interface OnMyGetRoutePlanResultListener{
        public void onGetBikingRouteResult(BikingRouteResult arg0);
        public void onGetDrivingRouteResult(DrivingRouteResult arg0);
        public void onGetTransitRouteResult(TransitRouteResult arg0) ;
        public void onGetWalkingRouteResult(WalkingRouteResult arg0);
    }
    private OnMyGetRoutePlanResultListener listener=null;
    public void setOnMyGetRoutePlanResultListener(OnMyGetRoutePlanResultListener listener){
        this.listener=listener;
    }

    /** 自行车 */
    public static final int BikingRoute=0;
    /** 驾车 */
    public static final int DrivingRoute=1;
    /** 公交 */
    public static final int TransitRoute=2;
    /** 步行 */
    public static final int WalkingRoute=3;

    public BaiduSearch(Context context){
        this.context=context;
        // 初始化搜索模块，注册事件监听
        mSearch = RoutePlanSearch.newInstance();
        mSearch.setOnGetRoutePlanResultListener(this);
    }
    /**发起路线规划搜索示例
     * @param start 起点
     * @param end 终点
     * @param passBy 途经点，仅在drivingSearch有效
     * @param state 选择搜索方式
     */
    public void SearchProcess(LatLng start,LatLng end,ArrayList<LatLng> passBy,int state) {
        ArrayList<PlanNode> arg0 =new ArrayList<PlanNode>();
        //设置起终点信息，对于tranistsearch 来说，城市名无意义
        PlanNode stNode = PlanNode.withLocation(start);
        PlanNode enNode = PlanNode.withLocation(end);
        if (passBy!=null) {
            for (int i = 0; i < passBy.size(); i++) {
                PlanNode node = PlanNode.withLocation(passBy.get(i));
                arg0.add(node);
            }
        }
        // 实际使用中请对起点终点城市进行正确的设定
        switch (state) {
            case BikingRoute:
                mSearch.bikingSearch((new BikingRoutePlanOption())
                        .from(stNode)
                        .to(enNode));
                break;
            case DrivingRoute:
                mSearch.drivingSearch((new DrivingRoutePlanOption())
                        .from(stNode)
                        .passBy(arg0)
                        .to(enNode));
                break;
            case TransitRoute:
                mSearch.transitSearch((new TransitRoutePlanOption())
                        .from(stNode)
                        .to(enNode));
                break;
            case WalkingRoute:
                mSearch.walkingSearch((new WalkingRoutePlanOption())
                        .from(stNode)
                        .to(enNode));
                break;
            default:
                break;
        }
    }
    @Override
    public void onGetDrivingRouteResult(DrivingRouteResult result) {
        // TODO Auto-generated method stub
        if (result == null || result.error != SearchResult.ERRORNO.NO_ERROR) {
            Toast.makeText(context, "抱歉，未找到结果", Toast.LENGTH_SHORT).show();
        }
        if (result.error == SearchResult.ERRORNO.AMBIGUOUS_ROURE_ADDR) {
            //起终点或途经点地址有岐义，通过以下接口获取建议查询信息
            //result.getSuggestAddrInfo()
            Toast.makeText(context, "抱歉，未找到结果", Toast.LENGTH_SHORT).show();
            return;
        }
        if (result.error == SearchResult.ERRORNO.NO_ERROR) {
            if (listener!=null) {
                listener.onGetDrivingRouteResult(result);
            }
        }
    }

    @Override
    public void onGetIndoorRouteResult(IndoorRouteResult indoorRouteResult) {

    }

    @Override
    public void onGetBikingRouteResult(BikingRouteResult result) {
        // TODO Auto-generated method stub
        if (result == null || result.error != SearchResult.ERRORNO.NO_ERROR) {
            Toast.makeText(context, "抱歉，未找到结果", Toast.LENGTH_SHORT).show();
        }
        if (result.error == SearchResult.ERRORNO.AMBIGUOUS_ROURE_ADDR) {
            //起终点或途经点地址有岐义，通过以下接口获取建议查询信息
            //result.getSuggestAddrInfo()
            Toast.makeText(context, "抱歉，未找到结果", Toast.LENGTH_SHORT).show();
            return;
        }
        if (result.error == SearchResult.ERRORNO.NO_ERROR) {
            if (listener!=null) {
                listener.onGetBikingRouteResult(result);
            }
        }
    }

    @Override
    public void onGetTransitRouteResult(TransitRouteResult result) {
        // TODO Auto-generated method stub
        if (result == null || result.error != SearchResult.ERRORNO.NO_ERROR) {
            Toast.makeText(context, "抱歉，未找到结果", Toast.LENGTH_SHORT).show();
        }
        if (result.error == SearchResult.ERRORNO.AMBIGUOUS_ROURE_ADDR) {
            //起终点或途经点地址有岐义，通过以下接口获取建议查询信息
            //result.getSuggestAddrInfo()
            Toast.makeText(context, "抱歉，未找到结果", Toast.LENGTH_SHORT).show();
            return;
        }
        if (result.error == SearchResult.ERRORNO.NO_ERROR) {
            if (listener!=null) {
                listener.onGetTransitRouteResult(result);
            }
        }
    }

    @Override
    public void onGetMassTransitRouteResult(MassTransitRouteResult massTransitRouteResult) {

    }

    @Override
    public void onGetWalkingRouteResult(WalkingRouteResult result) {
        // TODO Auto-generated method stub
        if (result == null || result.error != SearchResult.ERRORNO.NO_ERROR) {
            Toast.makeText(context, "抱歉，未找到结果", Toast.LENGTH_SHORT).show();
        }
        if (result.error == SearchResult.ERRORNO.AMBIGUOUS_ROURE_ADDR) {
            //起终点或途经点地址有岐义，通过以下接口获取建议查询信息
            //result.getSuggestAddrInfo()
            Toast.makeText(context, "抱歉，未找到结果", Toast.LENGTH_SHORT).show();
            return;
        }
        if (result.error == SearchResult.ERRORNO.NO_ERROR) {
            if (listener!=null) {
                listener.onGetWalkingRouteResult(result);
            }
        }
    }

}

