package com.example.lbstest;

import android.app.Application;
import android.content.ComponentName;
import android.content.Intent;
import android.content.ServiceConnection;
import android.os.IBinder;

import com.baidu.mapapi.SDKInitializer;
import com.iflytek.cloud.SpeechConstant;
import com.iflytek.cloud.SpeechUtility;

public class MyApplication extends Application {

    //语音合成服务
    MyTtsService mService;

    @Override  public void onCreate() {
        super.onCreate();
        SDKInitializer.initialize(this);
        SpeechUtility.createUtility(this, SpeechConstant.APPID + "=5d234311");

        Intent intent = new Intent(this,MyTtsService.class);
        bindService(intent,serviceConnection,BIND_AUTO_CREATE);

    }
    private ServiceConnection serviceConnection = new ServiceConnection() {
        @Override
        public void onServiceConnected(ComponentName name, IBinder service) {
            mService = ((MyTtsService.LocalBinder) service).getService();//获取服务对象
        }
        @Override
        public void onServiceDisconnected(ComponentName name) {
            mService = null;
        }
    };
}

