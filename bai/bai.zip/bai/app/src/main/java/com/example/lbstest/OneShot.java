package com.example.lbstest;

import android.Manifest;
import android.app.Activity;
import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.content.ServiceConnection;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.media.AudioManager;
import android.media.MediaPlayer;
import android.os.Build;
import android.os.Bundle;
import android.os.Environment;
import android.os.IBinder;
import android.support.v4.app.ActivityCompat;
import android.support.v4.content.ContextCompat;
import android.text.TextUtils;
import android.util.Log;
import android.widget.TextView;
import android.widget.Toast;

import com.chibde.visualizer.CircleBarVisualizer;
import com.example.lbstest.speech.setting.TtsSettings;
import com.example.lbstest.speech.util.FucUtil;
import com.example.lbstest.speech.util.JsonParser;
import com.iflytek.cloud.ErrorCode;
import com.iflytek.cloud.GrammarListener;
import com.iflytek.cloud.InitListener;
import com.iflytek.cloud.RecognizerListener;
import com.iflytek.cloud.RecognizerResult;
import com.iflytek.cloud.SpeechConstant;
import com.iflytek.cloud.SpeechError;
import com.iflytek.cloud.SpeechEvent;
import com.iflytek.cloud.SpeechRecognizer;
import com.iflytek.cloud.SpeechSynthesizer;
import com.iflytek.cloud.SpeechUtility;
import com.iflytek.cloud.SynthesizerListener;
import com.iflytek.cloud.VoiceWakeuper;
import com.iflytek.cloud.WakeuperListener;
import com.iflytek.cloud.WakeuperResult;
import com.iflytek.cloud.util.ResourceUtil;


import org.json.JSONException;
import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.ArrayList;



public class OneShot extends Activity {

    /**
     * 语音合成
     **/
    // 语音合成对象
    private SpeechSynthesizer mTts;
    // 默认云端发音人
    public static String voicerCloud = "xiaoyan";
    //缓冲进度
    private int mPercentForBuffering = 0;
    //播放进度
    private int mPercentForPlaying = 0;
    // 引擎类型
    private String mEngineType = SpeechConstant.TYPE_CLOUD;
    private Toast mToast;
    //参数选择
    private SharedPreferences mSharedPreferences;
    //书的行数
    int length = 0;
    int flag = 0;
    //字符串列表存书
    ArrayList<String> list;

    /**
     * 语音唤醒
     **/
    private TextView text;
    // 语音唤醒对象
    private VoiceWakeuper mIvw = null;
    // 唤醒结果内容
    private String resultString;
    //阈值
    private int curThresh = 1450;
    private String TAG = "ivw";


    /**
     * 语音识别
     **/
    // 语音识别对象
    private SpeechRecognizer mAsr;
    // 识别结果内容
    // private String resultString;
    // 本地语法id
    private String mLocalGrammarID;
    // 本地语法文件
    private String mLocalGrammar;
    // 本地语法构建路径
    private String grmPath = Environment.getExternalStorageDirectory().getAbsolutePath()
            + "/msc/test";
    private String ttsPath = Environment.getExternalStorageDirectory() + "/msc/tts.wav";
    //语法格式
    private final String GRAMMAR_TYPE_BNF = "bnf";
    String mContent;// 语法、词典临时变量
    int ret = 0;// 函数调用返回值

    /**
     * function
     */
    private boolean readFunction = false;
    private static boolean isPermissionRequested = false;

    //音频可视化
    MediaPlayer mediaPlayer;
    CircleBarVisualizer circleBarVisualizer;




    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        SpeechUtility.createUtility(this, SpeechConstant.APPID + "=5d234311");
        setContentView(R.layout.activity_one_shot);
        //申请权限
        requestPermission();
        //初始化组件
        initView();
        // 创建语音唤醒、识别、合成对象
        mIvw = VoiceWakeuper.createWakeuper(this, null);
        mAsr = SpeechRecognizer.createRecognizer(this, mInitListener);
        mTts = SpeechSynthesizer.createSynthesizer(this, mTtsInitListener);
        mSharedPreferences = getSharedPreferences(TtsSettings.PREFER_NAME, Activity.MODE_PRIVATE);
        //设置语音合成参数
        setTtsParam();
        //语音识别语法
        buildGrammer();
        //设置语音唤醒参数
        setIvwParam();
        Speaking("欢迎使用voice");
        mIvw.startListening(mWakeuperListener);
    }


    //初始化组件
    void initView(){
        //绑定组件
        text = (TextView) findViewById(R.id.text);
        circleBarVisualizer = (CircleBarVisualizer) findViewById(R.id.visualizer);
        circleBarVisualizer.setColor(ContextCompat.getColor(this, R.color.deepskyblue));
    }

    //发音
    void Speaking(String s){
        mTts.synthesizeToUri(s,ttsPath,mTtsListener);
    }
    private void playVoice(String mp3Path) {
        if (mp3Path.isEmpty())
            return;
        mediaPlayer = new MediaPlayer();
        circleBarVisualizer.setPlayer(mediaPlayer.getAudioSessionId());
        try {
            mediaPlayer.setDataSource(mp3Path);//指定音频文件的路径
            mediaPlayer.setAudioStreamType(AudioManager.STREAM_MUSIC);
            mediaPlayer.prepareAsync();//让mediaplayer进入准备状态
        } catch (IOException e) {
            e.printStackTrace();
            if (mediaPlayer != null) {
                mediaPlayer.stop();
                mediaPlayer.release();
                mediaPlayer = null;
            }
        }
        mediaPlayer.setOnCompletionListener(new MediaPlayer.OnCompletionListener() {
            @Override
            public void onCompletion(MediaPlayer mp) {
                // 在播放完毕被回调
                if (mediaPlayer != null) {
                    mediaPlayer.stop();
                    mediaPlayer.release();
                    mediaPlayer = null;
                }
                if (flag < length && readFunction){
                    Speaking(list.get(++flag));
                }
            }
        });
        mediaPlayer.setOnErrorListener(new MediaPlayer.OnErrorListener() {
            @Override
            public boolean onError(MediaPlayer mp, int what, int extra) {
                if (mediaPlayer != null) {
                    mediaPlayer.stop();
                    mediaPlayer.release();
                    mediaPlayer = null;
                }
                return true;
            }
        });
        mediaPlayer.setOnPreparedListener(new MediaPlayer.OnPreparedListener() {
            public void onPrepared(final MediaPlayer mp) {
                mp.start();//开始播放
                mp.seekTo(0);
            }
        });
    }

    //功能
    void myFunction(String function) {
        switch (function) {
            case "开启导航":
                Intent intent =new Intent(OneShot.this,MainActivity.class);
                intent.putExtra("yang","亨顺广场");
                startActivity(intent);
                break;
            case "我要读书":
                mTts.startSpeaking("你是个好孩子！", mTtsListener);
                readFunction = true;
                flag = 0;
                list = readFile(OneShot.this, "greek.txt", "UTF-8");
                length = list.size();
                Speaking(list.get(flag));
                break;
            case "继续读书":
                readFunction = true;
                Speaking(list.get(flag));
                break;
            case "徐绍越":
                Speaking("徐绍越是头猪");
                break;
            case "没有匹配结果":
                Speaking("没有匹配结果");
                break;
        }
    }

    /**
     * 语音唤醒
     */
    //初始化唤醒引擎
    private void setIvwParam() {
        mIvw = VoiceWakeuper.getWakeuper();
        if (mIvw != null) {
            resultString = "";
            text.setText(resultString);
            // 清空参数
            //mIvw.setParameter(SpeechConstant.PARAMS, null);
            // 唤醒门限值，根据资源携带的唤醒词个数按照“id:门限;id:门限”的格式传入
            mIvw.setParameter(SpeechConstant.IVW_THRESHOLD, "0:" + curThresh);
            // 设置唤醒模式
            mIvw.setParameter(SpeechConstant.IVW_SST, "wakeup");
            // 设置持续进行唤醒
            mIvw.setParameter(SpeechConstant.KEEP_ALIVE, "1");
            // 设置闭环优化网络模式
            mIvw.setParameter(SpeechConstant.IVW_NET_MODE, "0");
            // 设置唤醒资源路径
            mIvw.setParameter(SpeechConstant.IVW_RES_PATH, getResource());
            // 设置唤醒录音保存路径，保存最近一分钟的音频
            mIvw.setParameter(SpeechConstant.IVW_AUDIO_PATH, Environment.getExternalStorageDirectory().getPath() + "/msc/ivw.wav");
            mIvw.setParameter(SpeechConstant.AUDIO_FORMAT, "wav");
        } else {
            showTip("唤醒未初始化");
        }
    }

    //唤醒监听器
    private WakeuperListener mWakeuperListener = new WakeuperListener() {

        @Override
        public void onResult(WakeuperResult result) {
            try {
                String text = result.getResultString();
                JSONObject object;
                object = new JSONObject(text);
                StringBuffer buffer = new StringBuffer();
                buffer.append("【RAW】 " + text);
                buffer.append("\n");
                buffer.append("【操作类型】" + object.optString("sst"));
                buffer.append("\n");
                buffer.append("【唤醒词id】" + object.optString("id"));
                buffer.append("\n");
                buffer.append("【得分】" + object.optString("score"));
                buffer.append("\n");
                buffer.append("【前端点】" + object.optString("bos"));
                buffer.append("\n");
                buffer.append("【尾端点】" + object.optString("eos"));
                resultString = buffer.toString();
            } catch (JSONException e) {
                resultString = "结果解析出错";
                e.printStackTrace();
            }
            if (readFunction = true)
                readFunction = false;
            //mIvw.stopListening();
            Speaking("voice为您服务！");
            mAsr.startListening(mRecognizerListener);
        }

        @Override
        public void onError(SpeechError error) {
            resultString += "无录音权限！\n请同意或设置权限后重启。";
            mTts.startSpeaking("没有录音权限",mTtsListener);
            text.setText(resultString);
            showTip(error.getPlainDescription(true));
        }

        @Override
        public void onBeginOfSpeech() {
            //showTip("开启唤醒");
            if (readFunction == true) {
                mTts.pauseSpeaking();
            }
        }

        @Override
        public void onEvent(int eventType, int isLast, int arg2, Bundle obj) {

        }

        @Override
        public void onVolumeChanged(int volume) {
            // TODO Auto-generated method stub

        }

    };

    //获取唤醒资源路径
    private String getResource() {
        final String resPath = ResourceUtil.generateResourcePath(this, ResourceUtil.RESOURCE_TYPE.assets, "ivw/" + getString(R.string.app_id) + ".jet");
        Log.d("ivw", "resPath: " + resPath);
        return resPath;
    }


    /**
     * 语音识别
     */
    //构建语法
    private void buildGrammer() {
        mLocalGrammar = FucUtil.readFile(this, "function.bnf", "utf-8");
        // 本地-构建语法文件，生成语法id
        text.setText(FucUtil.readFile(this,"myfunction","utf-8"));
        mContent = new String(mLocalGrammar);
        //mAsr.setParameter(SpeechConstant.PARAMS, null);
        // 设置文本编码格式
        mAsr.setParameter(SpeechConstant.TEXT_ENCODING, "utf-8");
        // 设置引擎类型
        mAsr.setParameter(SpeechConstant.ENGINE_TYPE, SpeechConstant.TYPE_LOCAL);
        // 设置语法构建路径
        mAsr.setParameter(ResourceUtil.GRM_BUILD_PATH, grmPath);
        // 设置资源路径
        mAsr.setParameter(ResourceUtil.ASR_RES_PATH, getResourcePath());
        ret = mAsr.buildGrammar(GRAMMAR_TYPE_BNF, mContent, grammarListener);
    }


    //初始化语法构建监听器
    GrammarListener grammarListener = new GrammarListener() {
        @Override
        public void onBuildFinish(String grammarId, SpeechError error) {
            if (error == null) {
                mLocalGrammarID = grammarId;
                //showTip("语法构建成功：" + grammarId);
                //设置识别参数开始识别
                setParam();
            } else {
                showTip("语法构建失败,错误码：" + error.getErrorCode() + ",请点击网址https://www.xfyun.cn/document/error-code查询解决方案");
            }
        }
    };

    //设置语音识别参数
    public void setParam() {
        boolean result = true;
        // 清空参数
        //mAsr.setParameter(SpeechConstant.PARAMS, null);
        // 设置识别引擎
        mAsr.setParameter(SpeechConstant.ENGINE_TYPE, SpeechConstant.TYPE_LOCAL);
        // 设置本地识别资源
        mAsr.setParameter(ResourceUtil.ASR_RES_PATH, getResourcePath());
        // 设置语法构建路径
        mAsr.setParameter(ResourceUtil.GRM_BUILD_PATH, grmPath);
        // 设置返回结果格式
        mAsr.setParameter(SpeechConstant.RESULT_TYPE, "json");
        // 设置本地识别使用语法id
        mAsr.setParameter(SpeechConstant.LOCAL_GRAMMAR, mLocalGrammarID);
        mAsr.setParameter(SpeechConstant.KEY_SPEECH_TIMEOUT, "-1");
        mAsr.setParameter(SpeechConstant.VAD_BOS, "4000");
        mAsr.setParameter(SpeechConstant.VAD_EOS, "1000");
        // 设置识别的门限值
        mAsr.setParameter(SpeechConstant.MIXED_THRESHOLD, "30");
        //mediaPlayer.release();
        //ret = mAsr.startListening(mRecognizerListener);
        if (ret != ErrorCode.SUCCESS) {
            showTip("识别失败,错误码: " + ret);
        }
    }

    //初始化识别监听器。
    private InitListener mInitListener = new InitListener() {

        @Override
        public void onInit(int code) {
            Log.d(TAG, "SpeechRecognizer init() code = " + code);
            if (code != ErrorCode.SUCCESS) {
                showTip("初始化失败,错误码：" + code);
            }
        }
    };

    //识别监听器。
    private RecognizerListener mRecognizerListener = new RecognizerListener() {

        @Override
        public void onVolumeChanged(int volume, byte[] data) {
            showTip("当前正在说话，音量大小：" + volume);
            Log.d(TAG, "返回音频数据：" + data.length);
        }

        @Override
        public void onResult(final RecognizerResult result, boolean isLast) {
            if (null != result && !TextUtils.isEmpty(result.getResultString())) {
                String text1 = "";
                text1 = JsonParser.parseGrammarResult(result.getResultString(), SpeechConstant.TYPE_LOCAL);
                // 显示
                text.setText(text1);
                myFunction(JsonParser.function(result.getResultString()));
            }
        }

        @Override
        public void onEndOfSpeech() {
            // 此回调表示：检测到了语音的尾端点，已经进入识别过程，不再接受语音输入
            //showTip("结束说话");
            mAsr.stopListening();
            //mIvw.startListening(mWakeuperListener);
        }

        @Override
        public void onBeginOfSpeech() {
            // 此回调表示：sdk内部录音机已经准备好了，用户可以开始语音输入
            //showTip("开始说话");
        }

        @Override
        public void onError(SpeechError error) {
            if (error.getErrorCode() == 20005) {
                Speaking("没有匹配结果");
            } else if (error.getErrorCode() == 10118) {//没有数据
                text.setText("没有匹配结果");
                Speaking("没有匹配结果");
            } else {
                showTip("onError Code：" + error.getErrorCode());
            }
            showTip("onError Code：" + error.getErrorCode());
            mAsr.stopListening();
            //mIvw.startListening(mWakeuperListener);
        }

        @Override
        public void onEvent(int i, int i1, int i2, Bundle bundle) {
        }
    };

    //获取识别资源路径
    private String getResourcePath() {
        StringBuffer tempBuffer = new StringBuffer();
        //识别通用资源
        tempBuffer.append(ResourceUtil.generateResourcePath(this, ResourceUtil.RESOURCE_TYPE.assets, "asr/common.jet"));
        return tempBuffer.toString();
    }

    /**
     * 语音合成
     */

    //语音合成参数设置
    private void setTtsParam() {
        // 清空参数
        mTts.setParameter(SpeechConstant.PARAMS, null);
        //设置合成
        //设置使用云端引擎
        mTts.setParameter(SpeechConstant.ENGINE_TYPE, SpeechConstant.TYPE_CLOUD);
        //设置发音人
        mTts.setParameter(SpeechConstant.VOICE_NAME, voicerCloud);

        //mTts.setParameter(SpeechConstant.TTS_DATA_NOTIFY,"1");//支持实时音频流抛出，仅在synthesizeToUri条件下支持

        //设置合成语速、音调、音量、音频流类型
        mTts.setParameter(SpeechConstant.SPEED, mSharedPreferences.getString("speed_preference", "50"));
        mTts.setParameter(SpeechConstant.PITCH, mSharedPreferences.getString("pitch_preference", "50"));
        mTts.setParameter(SpeechConstant.VOLUME, mSharedPreferences.getString("volume_preference", "50"));
        mTts.setParameter(SpeechConstant.STREAM_TYPE, mSharedPreferences.getString("stream_preference", "3"));
        // 设置播放合成音频打断音乐播放，默认为true
        mTts.setParameter(SpeechConstant.KEY_REQUEST_FOCUS, "true");
        // 设置音频保存路径，保存音频格式支持pcm、wav，设置路径为sd卡请注意WRITE_EXTERNAL_STORAGE权限
        mTts.setParameter(SpeechConstant.AUDIO_FORMAT, "wav");
        mTts.setParameter(SpeechConstant.TTS_AUDIO_PATH, Environment.getExternalStorageDirectory() + "/msc/tts.wav");
    }

    //初始化监听
    private InitListener mTtsInitListener = new InitListener() {
        @Override
        public void onInit(int code) {
            if (code != ErrorCode.SUCCESS) {
                showTip("初始化失败,错误码：" + code + ",请点击网址https://www.xfyun.cn/document/error-code查询解决方案");
            } else {
                // 初始化成功，之后可以调用startSpeaking方法
                // 注：有的开发者在onCreate方法中创建完合成对象之后马上就调用startSpeaking进行合成，
                // 正确的做法是将onCreate中的startSpeaking调用移至这里
                //Speaking("欢迎使用voice");
            }
        }
    };

    //语音合成监听监听器
    private SynthesizerListener mTtsListener = new SynthesizerListener() {

        @Override
        public void onSpeakBegin() {
            //showTip("开始播放");
        }

        @Override
        public void onSpeakPaused() {
            //showTip("暂停播放");
        }

        @Override
        public void onSpeakResumed() {
            //showTip("继续播放");
        }

        @Override
        public void onBufferProgress(int percent, int beginPos, int endPos,
                                     String info) {
            // 合成进度
//            mPercentForBuffering = percent;
//            showTip(String.format(getString(R.string.tts_toast_format),
//                    mPercentForBuffering, mPercentForPlaying));
        }

        @Override
        public void onSpeakProgress(int percent, int beginPos, int endPos) {
            // 播放进度
//            mPercentForPlaying = percent;
//            showTip(String.format(getString(R.string.tts_toast_format),
//                    mPercentForBuffering, mPercentForPlaying));
        }

        @Override
        public void onCompleted(SpeechError error) {
            if (error == null) {
                playVoice(ttsPath);
            } else if (error != null) {
                readFunction = false;
                showTip(error.getPlainDescription(true));
            }
        }

        @Override
        public void onEvent(int eventType, int arg1, int arg2, Bundle obj) {

            //实时音频流输出参考
			if (SpeechEvent.EVENT_TTS_BUFFER == eventType) {
				//playVoice(ttsPath);
			}
        }
    };

    //语音合成读书
    public ArrayList readFile(Context mContext, String file, String code) {
        ArrayList<String> list = new ArrayList<>();
        try {
            InputStreamReader input = new InputStreamReader(
                    getResources().getAssets().open(file));
            BufferedReader buf = new BufferedReader(input);
            String line = "";
            while ((line = buf.readLine()) != null) {
                list.add(line);
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return list;
    }


    //onDestory
    @Override
    protected void onDestroy() {
        super.onDestroy();

        if (null != mTts) {
            mTts.stopSpeaking();
            // 退出时释放连接
            mTts.destroy();
        }
    }



    private void requestPermission() {
        if (Build.VERSION.SDK_INT >= 23 && !isPermissionRequested) {

            isPermissionRequested = true;

            ArrayList<String> permissionsList = new ArrayList<>();

            String[] permissions = {
                    Manifest.permission.RECORD_AUDIO,
                    Manifest.permission.ACCESS_NETWORK_STATE,
                    Manifest.permission.INTERNET,
                    Manifest.permission.WRITE_EXTERNAL_STORAGE,
                    Manifest.permission.READ_EXTERNAL_STORAGE,
                    Manifest.permission.ACCESS_COARSE_LOCATION,
                    Manifest.permission.ACCESS_FINE_LOCATION,
                    Manifest.permission.MODIFY_AUDIO_SETTINGS,
                    Manifest.permission.WRITE_SETTINGS,
                    Manifest.permission.ACCESS_WIFI_STATE,
                    Manifest.permission.CHANGE_WIFI_STATE,
                    Manifest.permission.CHANGE_WIFI_MULTICAST_STATE,
                    Manifest.permission.VIBRATE

            };

            for (String perm : permissions) {
                if (PackageManager.PERMISSION_GRANTED != checkSelfPermission(perm)) {
                    permissionsList.add(perm);
                    // 进入到这里代表没有权限.
                }
            }
            if (permissionsList.isEmpty()) {
                return;
            } else {
                requestPermissions(permissionsList.toArray(new String[permissionsList.size()]), 0);
            }
        }
    }


    //吐司
    private void showTip(final String str) {
        Toast.makeText(this, str, Toast.LENGTH_SHORT).show();
    }

}